
document.getElementById("addForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const title = document.getElementById("titleInput").value.trim();
    if (!title) return;

    const list = document.getElementById("list");
    const listItem = document.createElement("li");
    listItem.textContent = title;

    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Odstrániť";
    removeBtn.onclick = function() {
        list.removeChild(listItem);
    };

    listItem.appendChild(removeBtn);
    list.appendChild(listItem);

    document.getElementById("titleInput").value = "";
});
